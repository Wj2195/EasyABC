package com.easyabc.lenspro;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;

/** Optional, pinned HTTPS-only official filter packs; zero network access for photography. */
public final class FilterStore {
    public static final String CATALOG="https://wj2195.github.io/EasyABC/lenspro/catalog.json";
    private final Context context;
    public FilterStore(Context context){this.context=context.getApplicationContext();}
    public interface Listener { void result(String message, boolean updated); }
    public List<FilterPreset> load() {
        List<FilterPreset> filters=FilterPreset.defaults(context);
        Set<String> ids=new HashSet<>(); for(FilterPreset f:filters)ids.add(f.id);
        File dir=new File(context.getFilesDir(),"filter-packs"); File[] files=dir.listFiles();
        if(files!=null) for(File f:files) if(f.isFile()&&f.getName().endsWith(".json")) try {
            JSONObject pack=new JSONObject(new String(readFile(f,128000),java.nio.charset.StandardCharsets.UTF_8));
            JSONArray array=pack.getJSONArray("filters");
            for(int i=0;i<Math.min(array.length(),30);i++) {
                FilterPreset p=FilterPreset.fromJson(array.getJSONObject(i));
                if(ids.add(p.id))filters.add(p);
            }
        }catch(Exception ignored) { /* Invalid packs are ignored rather than crashing the camera */ }
        return filters;
    }
    public void checkForUpdates(Listener listener) {
        Executors.newSingleThreadExecutor().execute(()->{
            String message; boolean changed=false;
            try {
                JSONObject catalog=new JSONObject(new String(download(CATALOG,128000),java.nio.charset.StandardCharsets.UTF_8));
                if(catalog.getInt("schema")!=1) throw new Exception("Unsupported catalogue version");
                JSONArray packs=catalog.getJSONArray("packs"); if(packs.length()>25) throw new Exception("Catalogue too large");
                int installed=0;
                for(int i=0;i<packs.length();i++) {
                    JSONObject item=packs.getJSONObject(i);
                    String id=item.getString("id"); int version=item.getInt("version");
                    if(!id.matches("[a-z0-9-]{2,40}")||version<1||version>100000) throw new Exception("Invalid pack metadata");
                    int existing=context.getSharedPreferences("packs",0).getInt(id,0);
                    if(version<=existing)continue;
                    String remote=item.getString("url"),sha=item.getString("sha256");
                    if(!sha.matches("[0-9a-f]{64}"))throw new Exception("Invalid checksum");
                    byte[] data=download(remote,128000);
                    if(!sha.equals(hex(MessageDigest.getInstance("SHA-256").digest(data)))) throw new Exception("Checksum mismatch: "+id);
                    JSONObject pack=new JSONObject(new String(data,java.nio.charset.StandardCharsets.UTF_8));
                    if(!id.equals(pack.getString("id")))throw new Exception("Pack ID mismatch");
                    JSONArray fs=pack.getJSONArray("filters");
                    if(fs.length()==0||fs.length()>30) throw new Exception("Invalid pack size");
                    for(int j=0;j<fs.length();j++) FilterPreset.fromJson(fs.getJSONObject(j));
                    File dir=new File(context.getFilesDir(),"filter-packs"); if(!dir.exists()&&!dir.mkdirs())throw new Exception("Cannot create filter library");
                    File stage=new File(dir,id+".tmp");
                    try(FileOutputStream out=new FileOutputStream(stage)){out.write(data);out.getFD().sync();}
                    File target=new File(dir,id+".json");
                    if(!stage.renameTo(target)) {stage.delete();throw new Exception("Could not install filter pack");}
                    context.getSharedPreferences("packs",0).edit().putInt(id,version).apply(); installed++; changed=true;
                }
                message=installed>0?"Installed "+installed+" official filter pack(s). Ready to use offline.":"Your filter library is up to date.";
            } catch(java.io.FileNotFoundException e){message="The official online filter catalogue is not published yet. Your built-in filters work offline.";}
              catch(Exception e){message="Filter update unavailable. Built-in and downloaded filters still work offline. ("+e.getClass().getSimpleName()+")";}
            boolean finalChanged=changed;String finalMessage=message;
            new Handler(Looper.getMainLooper()).post(()->listener.result(finalMessage,finalChanged));
        });
    }
    private static byte[] readFile(File f,int limit)throws Exception{
        try(InputStream in=new FileInputStream(f)){return read(in,limit);}
    }
    private static byte[] download(String location,int limit)throws Exception{
        URL url=new URL(location);
        if(!"https".equalsIgnoreCase(url.getProtocol())||!"wj2195.github.io".equalsIgnoreCase(url.getHost())||!url.getPath().startsWith("/EasyABC/lenspro/")) throw new Exception("Untrusted filter host");
        HttpURLConnection conn=(HttpURLConnection)url.openConnection();conn.setConnectTimeout(9000);conn.setReadTimeout(9000);conn.setInstanceFollowRedirects(false);
        try {if(conn.getResponseCode()!=200)throw new java.io.FileNotFoundException("Catalogue not found");
            try(InputStream in=conn.getInputStream()){return read(in,limit);}
        } finally {conn.disconnect();}
    }
    private static byte[] read(InputStream in,int limit)throws Exception{
        ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] bytes=new byte[4096];int n;
        while((n=in.read(bytes))!=-1){if(buf.size()+n>limit)throw new Exception("Filter download too large");buf.write(bytes,0,n);}return buf.toByteArray();
    }
    private static String hex(byte[] data){StringBuilder sb=new StringBuilder();for(byte b:data)sb.append(String.format(java.util.Locale.US,"%02x",b&255));return sb.toString();}
}
