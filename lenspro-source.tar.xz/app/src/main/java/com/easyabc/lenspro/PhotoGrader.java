package com.easyabc.lenspro;

import android.graphics.Bitmap;

/**
 * Lightroom-inspired on-device photo development engine (independent implementation).
 * Read-only EasyABC recipes from the original 40-row workbook drive tone curve,
 * highlight/shadow recovery, vibrance, 8-sector HSL mixing, local clarity/texture,
 * fine film grain and edge vignette. No global blue-channel gain is ever applied.
 *
 * Camera ISO and shutter are capture-only parameters and cannot be changed in a JPEG.
 */
public final class PhotoGrader {
    private PhotoGrader(){}
    private static float clamp(float x,float lo,float hi){return Math.min(hi,Math.max(lo,x));}
    private static float smooth(float a,float b,float x){x=clamp((x-a)/(b-a),0,1);return x*x*(3-2*x);}
    private static float lum(int rgb){return (((rgb>>16)&255)*.2126f+((rgb>>8)&255)*.7152f+(rgb&255)*.0722f)/255f;}
    private static boolean isMatte(String id){return id.contains("vintage")||id.contains("pastel")||id.contains("misty")||id.contains("soft-beauty")||id.contains("rainy-cafe");}
    private static int out8(float x){return (int)(clamp(x,0,1)*255+.5f);}
    private static float lerp(float a,float b,float k){return a+(b-a)*k;}
    /** Full-quality photo export. On gallery photos AE EV is represented as a conservative post-exposure compensation. */
    public static Bitmap apply(Bitmap source,FilterPreset p){return apply(source,p,false);}
    public static Bitmap apply(Bitmap source,FilterPreset p,boolean imported){
        int w=source.getWidth(),h=source.getHeight();
        Bitmap result=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        int[] row=new int[w],prev=new int[w],next=new int[w],outputRow=new int[w];
        source.getPixels(row,0,w,0,0,w,1);
        if(h>1)source.getPixels(next,0,w,0,1,w,1);
        else System.arraycopy(row,0,next,0,w);
        System.arraycopy(row,0,prev,0,w);
        float contrast=clamp(p.contrast/100f,-1,1),hAdj=clamp(p.highlights/100f,-1,1),sAdj=clamp(p.shadows/100f,-1,1);
        float satAdj=p.saturation/100f,vibAdj=p.vibrance/100f,clarity=p.clarity/100f;
        float grain=p.grain/100f,vig=p.vignette/100f;
        boolean matte=isMatte(p.id),mono=p.saturation<=-95;
        float evMultiplier=imported?(float)Math.pow(2,clamp(p.exposureEv,-.7f,.7f)*.48f):1f;
        float wbStrength=clamp((p.whiteBalanceK-5200f)/2900f,-.8f,.8f);
        float[] adjusted=new float[3];
        for(int y=0;y<h;y++){
            float ny=(y+.5f)/(float)h-.5f;
            for(int x=0;x<w;x++){
                int original=row[x];float r=((original>>16)&255)/255f,g=((original>>8)&255)/255f,b=(original&255)/255f;
                float vmax=Math.max(r,Math.max(g,b)),vmin=Math.min(r,Math.min(g,b)),delta=vmax-vmin;
                float L=.2126f*r+.7152f*g+.0722f*b;
                float neutral=(1-smooth(.012f,.11f,delta))*(.70f+.3f*smooth(.18f,.85f,L));
                // HSV wheel for 8-bin colour mixer; hue does not affect true neutral areas.
                float hDeg=0;
                if(delta>.0001f){
                    if(vmax==r)hDeg=60f*((g-b)/delta);
                    else if(vmax==g)hDeg=60f*(2f+(b-r)/delta);
                    else hDeg=60f*(4f+(r-g)/delta);
                    if(hDeg<0)hDeg+=360f;
                }
                float hsvSat=vmax<.00001f?0:delta/vmax;
                // Soft skin safeguard applies to every category, not just PEOPLE.
                float skin=(hDeg<55f||hDeg>354f)?smooth(.09f,.27f,hsvSat)*(1-smooth(.67f,.86f,hsvSat))
                    *smooth(.12f,.36f,L)*(1-smooth(.88f,1,L)):0;
                if(hDeg>40f&&hDeg<=55f)skin*=1-smooth(40f,55f,hDeg);
                // Per-preset tone curve from actual workbook sliders, with independent highlights and shadows.
                float t=L*evMultiplier;
                t=clamp(t,0,1.2f);
                t+=contrast*(t-.5f)*(.78f-.33f*Math.abs(t-.5f));
                float shadowMask=1-smooth(.10f,.67f,L),highlightMask=smooth(.38f,.92f,L);
                t+=sAdj*.28f*shadowMask*(.35f+.65f*smooth(0,.25f,L));
                t+=hAdj*.29f*highlightMask*(1-.40f*smooth(.94f,1f,L));
                // Creative black point: matte film fades blacks, cinematic shadows deepen them.
                if(matte)t+=(.026f+Math.max(0,-contrast)*.016f)*(1-smooth(.04f,.52f,L));
                else if(contrast>.12f)t-=contrast*.043f*(1-smooth(.01f,.40f,L));
                // Whites stay optically white: night presets may tame glare but must not gray out clothing or lamps.
                float whiteLumaProtection=neutral*smooth(.72f,.97f,L);
                t=lerp(t,L,whiteLumaProtection*.85f);
                // local contrast (clarity) computed from unfiltered neighbors at multiple scales
                int i0=Math.max(0,x-5),i1=Math.min(w-1,x+5);
                float local=(lum(row[i0])+lum(row[i1])+lum(prev[x])+lum(next[x]))*.25f;
                float highFreq=L-local;
                float skinProtection=1-skin*.77f;
                t+=highFreq*clarity*.88f*skinProtection*(.37f+.63f*(1-Math.abs(L-.5f)*1.4f));
                // Slight texture softening on portraits with negative clarity without erasing eyes.
                t=clamp(t,0,1);
                // 8-sector colour mixer driven by per-filter HSL values (different from brightness-only filters).
                float bin=hDeg/45f;
                int sector=(int)bin;
                if(sector>=8)sector=7;
                int second=(sector+1)%8;
                float fraction=bin-sector;
                float shift=lerp(p.hslHue[sector],p.hslHue[second],fraction);
                float sectorSat=lerp(p.hslSat[sector],p.hslSat[second],fraction)/100f;
                float colourProtection=(1-neutral*.98f)*(1-skin*.94f);
                float hueOut=(hDeg+shift*colourProtection+360f)%360f;
                float satFactor=1f+satAdj*(1-neutral*.98f)*(1-skin*.75f)+sectorSat*colourProtection;
                // Vibrance prefers muted colour; naturally coloured skin is protected.
                satFactor+=vibAdj*.88f*(1-hsvSat)*(1-neutral*.95f)*(1-skin*.80f);
                float newSat=mono?0f:clamp(hsvSat*satFactor,0,1);
                // Decode adjusted hue and saturation while keeping original brightness (tonality addressed below).
                float Chroma=vmax*newSat,hh=hueOut/60f;
                float X=Chroma*(1-Math.abs(hh%2f-1));
                float rr=0,gg=0,bb=0;
                if(hh<1){rr=Chroma;gg=X;}
                else if(hh<2){rr=X;gg=Chroma;}
                else if(hh<3){gg=Chroma;bb=X;}
                else if(hh<4){gg=X;bb=Chroma;}
                else if(hh<5){rr=X;bb=Chroma;}
                else {rr=Chroma;bb=X;}
                float m=vmax-Chroma;
                rr+=m;gg+=m;bb+=m;
                // Split toning: subtle warm highlights/cool shadows only where there is colour.
                // Neutral white lights / shirts retain balanced RGB, and faces cannot go blue.
                float shadowMix=(1-smooth(.22f,.76f,L)),highMix=smooth(.40f,.88f,L);
                float warm=(p.shadowGrade*shadowMix+p.highlightGrade*highMix)/100f;
                warm+=wbStrength*.015f*(.65f+.35f*highMix);
                warm*=colourProtection*(1-skin*.90f);
                rr+=warm*.11f;bb-=warm*.10f;gg+=warm*.010f;
                // Explicit neutral safeguard even after WB and split toning.
                float chromaL=.2126f*rr+.7152f*gg+.0722f*bb;
                rr=lerp(rr,chromaL,neutral);gg=lerp(gg,chromaL,neutral);bb=lerp(bb,chromaL,neutral);
                // Tonal image is applied without a per-channel brightness cast.
                float postL=.2126f*rr+.7152f*gg+.0722f*bb;
                float dy=t-postL;
                rr+=dy;gg+=dy;bb+=dy;
                // Preserve relative colour at clipping: scale the chroma towards luminance.
                float over=Math.max(rr,Math.max(gg,bb)),under=Math.min(rr,Math.min(gg,bb));
                if(over>1||under<0){
                    float scale=1f;
                    if(over>1 && over>t)scale=Math.min(scale,(1-t)/(over-t));
                    if(under<0 && under<t)scale=Math.min(scale,t/(t-under));
                    scale=clamp(scale,0,1);
                    rr=t+(rr-t)*scale;gg=t+(gg-t)*scale;bb=t+(bb-t)*scale;
                }
                float nx=(x+.5f)/(float)w-.5f;
                float radius=clamp((nx*nx*1.15f+ny*ny*1.05f)*2.25f,0,1.2f);
                float edge=smooth(.22f,1.10f,radius);
                float dark=vig*.34f*edge;
                rr*=(1-dark);gg*=(1-dark);bb*=(1-dark);
                if(grain>0){
                    int seed=(x*73856093)^(y*19349663)^0x7f4a7c15;
                    seed^=seed>>>13;seed*=1274126177;seed^=seed>>>16;
                    float noise=((seed&65535)/32767.5f-1f)*grain*.045f*(.35f+.65f*(1-L));
                    rr+=noise;gg+=noise;bb+=noise;
                }
                adjusted[0]=rr;adjusted[1]=gg;adjusted[2]=bb;
                outputRow[x]=(original&0xff000000)|(out8(adjusted[0])<<16)|(out8(adjusted[1])<<8)|out8(adjusted[2]);
            }
            result.setPixels(outputRow,0,w,0,y,w,1);
            // Shift RAW source rows; never use graded results as neighbouring inputs.
            int[] old=prev;prev=row;row=next;next=old;
            if(y+2<h)source.getPixels(next,0,w,0,y+2,w,1);
            else System.arraycopy(row,0,next,0,w);
        }
        return result;
    }
}
