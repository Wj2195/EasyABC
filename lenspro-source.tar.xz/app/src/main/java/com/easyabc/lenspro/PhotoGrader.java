package com.easyabc.lenspro;

import android.graphics.Bitmap;

/**
 * Channel-neutral, locally adaptive still photo processing.
 * Pure Java on-device, no ML model and no network requirement.
 * Skin-like orange/red pixels and nearly white highlights are explicitly protected.
 * Scenery hues (vegetation/water/sky) receive selective emphasis instead of a global blue cast.
 */
public final class PhotoGrader {
    private PhotoGrader(){}
    private static float clamp(float x,float min,float max){return x<min?min:Math.min(max,x);}
    private static float smooth(float a,float b,float x){x=clamp((x-a)/(b-a),0,1);return x*x*(3-2*x);}
    public static Bitmap apply(Bitmap src, FilterPreset preset){
        int width=src.getWidth(),height=src.getHeight();
        Bitmap out=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        int[] row=new int[width];
        for(int y=0;y<height;y++){
            src.getPixels(row,0,width,0,y,width,1);
            for(int x=0;x<width;x++){
                int c=row[x];
                float r=(c>>16)&255,g=(c>>8)&255,b=c&255;
                float lo=Math.min(r,Math.min(g,b)),hi=Math.max(r,Math.max(g,b));
                float chroma=hi-lo;
                float lum=.2126f*r+.7152f*g+.0722f*b;
                float white=smooth(155,235,lum)*(1-smooth(.055f,.17f,chroma/(hi+1)));
                float skin=(r>g && g>b*.86f && r>b*1.12f)?
                   smooth(42,100,r)*smooth(.035f,.20f,(r-g)/(r+1))*
                   (1-smooth(.52f,.78f,(r-b)/(r+1))):0;
                // Skin and neutral areas keep the original channel ratios.
                float protectedAmount=Math.max(white*.99f,skin*.92f);
                float effectiveSaturation=preset.saturation/100f*(1-skin*.75f)*(1-white*.95f);
                float saturation=clamp(1+effectiveSaturation,0,1.45f);
                r=lum+(r-lum)*saturation;
                g=lum+(g-lum)*saturation;
                b=lum+(b-lum)*saturation;
                float contrast=1+preset.contrast*(1-skin*.32f);
                float targetLum=clamp(((lum-128)*contrast+128+preset.lightness*.72f),0,255);
                float shift=targetLum-lum;
                r+=shift;g+=shift;b+=shift;
                // Class-specific hue enhancement is weighted by chroma & scene structure.
                float vivid=smooth(13,65,chroma)*(1-protectedAmount);
                float greenMask=(g>r*1.04f && g>b*1.02f)?smooth(3,55,g-Math.max(r,b)):0;
                float blueMask=(b>r*1.09f && b>g*.99f)?smooth(3,58,b-r):0;
                float greenAmount=preset.greenBoost*greenMask*vivid*45f;
                float blueAmount=preset.blueBoost*blueMask*vivid*48f;
                g+=greenAmount; r-=greenAmount*.22f;
                b+=blueAmount; r-=blueAmount*.18f;
                // Warmth applies mainly to already-warm coloured regions, not to white objects.
                float warmArea=(r>g*.98f && g>b*.90f)?smooth(8,70,r-b):0;
                float tint=preset.warmth*warmArea*vivid*35f;
                r+=tint;g+=tint*.28f;b-=tint*.56f;
                // Force near-neutral whites to stay neutral, including artificial lamps.
                float finalLum=.2126f*r+.7152f*g+.0722f*b;
                r=r*(1-white)+finalLum*white;
                g=g*(1-white)+finalLum*white;
                b=b*(1-white)+finalLum*white;
                row[x]=(c&0xff000000)|((int)clamp(r+.5f,0,255)<<16)|((int)clamp(g+.5f,0,255)<<8)|(int)clamp(b+.5f,0,255);
            }
            out.setPixels(row,0,width,0,y,width,1);
        }
        return out;
    }
}
