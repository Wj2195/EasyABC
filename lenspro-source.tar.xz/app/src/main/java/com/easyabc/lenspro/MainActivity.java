package com.easyabc.lenspro;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RenderEffect;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.util.Range;
import androidx.camera.camera2.interop.Camera2CameraInfo;
import androidx.camera.camera2.interop.Camera2CameraControl;
import androidx.camera.camera2.interop.CaptureRequestOptions;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import androidx.activity.result.ActivityResultLauncher;
import java.util.concurrent.atomic.AtomicInteger;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.exifinterface.media.ExifInterface;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Effect;
import androidx.media3.effect.Contrast;
import androidx.media3.effect.HslAdjustment;
import androidx.media3.effect.RgbAdjustment;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@androidx.media3.common.util.UnstableApi
public final class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(11,14,20), PANEL=Color.rgb(22,27,36), GOLD=Color.rgb(222,188,116), WHITE=Color.rgb(243,242,235), MUTED=Color.rgb(161,170,185);
    private PreviewView preview;
    private ImageView galleryImage;
    private TextView galleryButton;
    private Bitmap gallerySource,galleryPreviewBitmap;
    private boolean galleryMode=false;
    private final AtomicInteger galleryGeneration=new AtomicInteger();
    private final ActivityResultLauncher<String> photoPicker=registerForActivityResult(new ActivityResultContracts.GetContent(),this::openGalleryPhoto);
    private TextView selectedLabel, status, shutter, modeButton, cameraButton, updatesButton, shareButton, countLabel, beautyButton;
    private LinearLayout strip;
    private LinearLayout categoryTabs;
    private String filterCategory="SCENERY";
    private Camera boundCamera;
    private String currentSensorMode="AUTO";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    // Camera does not wait for photo grading/compression to finish.
    private final ExecutorService photoWorker=Executors.newSingleThreadExecutor();
    private final ExecutorService cameraCallbackWorker=Executors.newSingleThreadExecutor();
    private final AtomicInteger pendingPhotoSaves=new AtomicInteger();
    private final BeautyProcessor beautyProcessor=new BeautyProcessor();
    private int beautyMode=0; // 0: off, 1: soft skin, 2: face slim, 3: face + body slim

    private List<FilterPreset> filters;
    private FilterPreset selected;
    private FilterStore store;
    private ImageCapture imageCapture;
    private VideoCapture<Recorder> videoCapture;
    private Recording recording;
    private boolean videoMode=false, busy=false, front=false;
    private Uri lastUri;
    private String lastMime="image/jpeg";
    private Transformer activeTransformer;
    private File recordingTemp;

    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        store=new FilterStore(this);filters=store.load();selected=filters.get(10);
        buildUi();refreshFilters();requestCamera();
    }
    private int d(float dp){return (int)(dp*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable rounded(int color,int radius){GradientDrawable gd=new GradientDrawable();gd.setColor(color);gd.setCornerRadius(d(radius));return gd;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(sp);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);heading.setPadding(d(18),d(12),d(18),d(10));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(text("EASYABC  /  LENS PRO",17,WHITE,true));
        brand.addView(text("CAPTURE THE EXTRAORDINARY",9,GOLD,true));
        heading.addView(brand,new LinearLayout.LayoutParams(0,d(51),1));
        updatesButton=text("FILTERS  ↻",11,GOLD,true);updatesButton.setGravity(Gravity.CENTER);updatesButton.setPadding(d(9),0,d(9),0);
        updatesButton.setBackground(rounded(PANEL,14));heading.addView(updatesButton,new LinearLayout.LayoutParams(d(108),d(41)));
        updatesButton.setOnClickListener(v->checkUpdates());root.addView(heading);

        FrameLayout canvas=new FrameLayout(this);canvas.setBackgroundColor(Color.rgb(24,31,39));
        preview=new PreviewView(this);preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        canvas.addView(preview,new FrameLayout.LayoutParams(-1,-1));
        galleryImage=new ImageView(this);galleryImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        galleryImage.setBackgroundColor(0xFF0B0E14);galleryImage.setVisibility(View.GONE);
        canvas.addView(galleryImage,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setPadding(d(17),d(18),d(17),0);top.setOrientation(LinearLayout.VERTICAL);
        selectedLabel=text("NATURE PRO",13,WHITE,true);selectedLabel.setPadding(d(12),0,d(12),0);selectedLabel.setBackground(rounded(0xB30B0E14,12));
        top.addView(selectedLabel,new LinearLayout.LayoutParams(-2,d(36)));
        status=text("● READY · OFFLINE CAMERA",10,WHITE,true);status.setPadding(d(12),d(8),d(12),d(8));status.setBackground(rounded(0xB30B0E14,10));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2);sp.topMargin=d(10);top.addView(status,sp);
        FrameLayout.LayoutParams topP=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);canvas.addView(top,topP);
        root.addView(canvas,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(d(12),d(12),d(12),d(17));root.addView(controls);
        LinearLayout info=new LinearLayout(this);info.setGravity(Gravity.CENTER_VERTICAL);info.setPadding(d(5),0,d(5),d(7));
        TextView label=text("PROFESSIONAL PRESETS",10,MUTED,true);info.addView(label,new LinearLayout.LayoutParams(0,d(22),1));
        countLabel=text("",10,GOLD,false);info.addView(countLabel);controls.addView(info);
        categoryTabs=new LinearLayout(this);categoryTabs.setGravity(Gravity.CENTER_VERTICAL);
        HorizontalScrollView categoryScroll=new HorizontalScrollView(this);categoryScroll.setHorizontalScrollBarEnabled(false);
        categoryScroll.addView(categoryTabs);controls.addView(categoryScroll,new LinearLayout.LayoutParams(-1,d(44)));
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);
        strip=new LinearLayout(this);strip.setOrientation(LinearLayout.HORIZONTAL);scroller.addView(strip);controls.addView(scroller,new LinearLayout.LayoutParams(-1,d(65)));

        beautyButton=text("✧  SELFIE BEAUTY: OFF",12,WHITE,true);beautyButton.setGravity(Gravity.CENTER);
        beautyButton.setBackground(rounded(PANEL,13));
        LinearLayout.LayoutParams beautyParams=new LinearLayout.LayoutParams(-1,d(38));
        beautyParams.setMargins(0,d(5),0,d(2));
        controls.addView(beautyButton,beautyParams);
        beautyButton.setOnClickListener(v->{
            if(busy||recording!=null)return;
            beautyMode=(beautyMode+1)%4;
            String[] names={"OFF","SOFT SKIN","FACE SLIM","FACE + BODY SLIM"};
            beautyButton.setText("✧  SELFIE BEAUTY: "+names[beautyMode]);
            beautyButton.setTextColor(beautyMode==0?WHITE:GOLD);
            if(galleryMode)renderGalleryPreview();
            else setStatus(beautyMode==0?"● BEAUTY OFF":"● BEAUTY MODE: "+names[beautyMode]);
        });

        galleryButton=text("▣  EDIT A PHOTO FROM GALLERY",12,GOLD,true);galleryButton.setGravity(Gravity.CENTER);
        galleryButton.setBackground(rounded(PANEL,13));
        LinearLayout.LayoutParams galleryParams=new LinearLayout.LayoutParams(-1,d(42));galleryParams.setMargins(0,d(8),0,d(6));
        controls.addView(galleryButton,galleryParams);
        galleryButton.setOnClickListener(v->{if(!busy&&recording==null)photoPicker.launch("image/*");});

        LinearLayout modes=new LinearLayout(this);modes.setGravity(Gravity.CENTER);modes.setPadding(0,d(6),0,d(2));
        modeButton=text("PHOTO   /   VIDEO",12,WHITE,true);modeButton.setGravity(Gravity.CENTER);modeButton.setBackground(rounded(PANEL,13));
        modes.addView(modeButton,new LinearLayout.LayoutParams(d(165),d(39)));controls.addView(modes);
        modeButton.setOnClickListener(v->{if(busy||recording!=null)return;if(galleryMode){returnToCamera();return;}videoMode=!videoMode;modeButton.setText(videoMode?"VIDEO   ●  /   PHOTO":"PHOTO   ●  /   VIDEO");shutter.setText(videoMode?"●":"◎");configureCameraPreset();setStatus(videoMode?"VIDEO · READY":"PHOTO · READY");});

        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);actions.setPadding(d(13),d(7),d(13),0);
        shareButton=text("↗ SHARE",11,WHITE,true);shareButton.setGravity(Gravity.CENTER);shareButton.setBackground(rounded(PANEL,12));actions.addView(shareButton,new LinearLayout.LayoutParams(0,d(50),1));
        shareButton.setOnClickListener(v->shareLast());
        shutter=text("◎",44,GOLD,true);shutter.setGravity(Gravity.CENTER);GradientDrawable ring=rounded(PANEL,100);ring.setStroke(d(3),GOLD);shutter.setBackground(ring);
        LinearLayout.LayoutParams shutterP=new LinearLayout.LayoutParams(d(78),d(78));shutterP.setMargins(d(20),0,d(20),0);actions.addView(shutter,shutterP);shutter.setOnClickListener(v->capture());
        cameraButton=text("⇄ FLIP",11,WHITE,true);cameraButton.setGravity(Gravity.CENTER);cameraButton.setBackground(rounded(PANEL,12));actions.addView(cameraButton,new LinearLayout.LayoutParams(0,d(50),1));
        cameraButton.setOnClickListener(v->{if(busy||recording!=null)return;if(galleryMode){returnToCamera();return;}front=!front;
            filterCategory=front?"PEOPLE":"SCENERY";
            for(FilterPreset f:filters)if(f.collection.equals(filterCategory)){selected=f;break;}
            selectedLabel.setText(selected.name);refreshFilters();startCamera();});
        controls.addView(actions);
        TextView legal=text("EASYABC  •  OFFLINE CAMERA  •  OFFICIAL PRESETS ONLY",9,MUTED,false);legal.setGravity(Gravity.CENTER);legal.setPadding(0,d(12),0,0);controls.addView(legal);
    }
    private void refreshFilters(){
        // Exactly 40 official default filters, ten in each purpose-built category.
        categoryTabs.removeAllViews();
        String[] categories={"ALL","PEOPLE","SCENERY","CITY VIEW","FOOD & DRINKS"};
        String[] labels={"ALL · 40","SELFIE / PEOPLE","SCENERY","CITY / CAFÉ","FOOD & DRINKS"};
        for(int i=0;i<categories.length;i++){
            String cat=categories[i];boolean active=cat.equals(filterCategory);
            TextView tab=text(labels[i],11,active?BG:WHITE,true);tab.setGravity(Gravity.CENTER);
            tab.setPadding(d(15),0,d(15),0);
            tab.setBackground(rounded(active?GOLD:PANEL,11));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,d(35));lp.setMargins(0,0,d(7),0);
            categoryTabs.addView(tab,lp);
            tab.setOnClickListener(v->{if(busy||recording!=null)return;
                filterCategory=cat;
                if(!"ALL".equals(cat)&&!cat.equals(selected.collection)){
                    for(FilterPreset f:filters)if(f.collection.equals(cat)){selected=f;selectedLabel.setText(f.name);break;}
                }
                refreshFilters();configureCameraPreset();
            });
        }
        strip.removeAllViews();int visible=0;
        for(FilterPreset f:filters){
            if(!"ALL".equals(filterCategory)&&!filterCategory.equals(f.collection))continue;
            visible++;
            boolean active=f.id.equals(selected.id);
            TextView t=text(f.name,10,active?BG:WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(d(14),0,d(14),0);
            GradientDrawable bd=rounded(active?GOLD:PANEL,12);if(!active)bd.setStroke(d(1),0xFF343D4D);t.setBackground(bd);
            LinearLayout.LayoutParams item=new LinearLayout.LayoutParams(-2,d(49));item.setMargins(0,0,d(8),0);strip.addView(t,item);
            t.setOnClickListener(v->{if(busy||recording!=null)return;selected=f;selectedLabel.setText(f.name);refreshFilters();configureCameraPreset();});
        }
        countLabel.setText(visible+" / "+filters.size()+" PRESETS");
        if(galleryMode)renderGalleryPreview();else applyLiveLook();
    }
    private void applyLiveLook(){
        if(preview!=null&&Build.VERSION.SDK_INT>=31){try{preview.setRenderEffect(RenderEffect.createColorFilterEffect(selected.colorFilter()));}catch(Exception ignored){}}
    }
    private void requestCamera(){
        ArrayList<String> missing=new ArrayList<>();
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CAMERA);
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO);
        if(missing.isEmpty())startCamera();else requestPermissions(missing.toArray(new String[0]),101);
    }
    @Override public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==101){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();else setStatus("CAMERA PERMISSION REQUIRED");}
    }
    private void startCamera(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        ProcessCameraProvider.getInstance(this).addListener(()->{
            try{
                ProcessCameraProvider provider=ProcessCameraProvider.getInstance(this).get();provider.unbindAll();
                CameraSelector facing=front?CameraSelector.DEFAULT_FRONT_CAMERA:CameraSelector.DEFAULT_BACK_CAMERA;
                if(!provider.hasCamera(facing)){front=!front;facing=front?CameraSelector.DEFAULT_FRONT_CAMERA:CameraSelector.DEFAULT_BACK_CAMERA;}
                Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());
                imageCapture=new ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setJpegQuality(92).build();
                Recorder recorder=new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD, androidx.camera.video.FallbackStrategy.higherQualityOrLowerThan(Quality.HD))).build();
                videoCapture=VideoCapture.withOutput(recorder);
                boundCamera=provider.bindToLifecycle(this,facing,p,imageCapture,videoCapture);
                configureCameraPreset();applyLiveLook();setStatus("● READY · "+(front?"FRONT":"REAR")+" CAMERA · "+currentSensorMode);
            }catch(Exception e){setStatus("CAMERA UNAVAILABLE");Toast.makeText(this,"Camera error: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        },ContextCompat.getMainExecutor(this));
    }
    /** Camera2 device-aware exposure profile. User cannot change this. */
    private void configureCameraPreset(){
        Camera camera=boundCamera;
        if(camera==null||selected==null||galleryMode)return;
        FilterPreset p=selected;
        currentSensorMode="AUTO WB / AUTO ISO";
        try {
            Camera2CameraControl control=Camera2CameraControl.from(camera.getCameraControl());
            // Reset camera options as each preset is selected; never retain night ISO for selfies.
            control.clearCaptureRequestOptions();
            boolean supported=false;
            if(!videoMode && p.manualExposure && p.targetIso>0 && p.exposureMillis>0){
                int[] capabilities=Camera2CameraInfo.from(camera.getCameraInfo()).getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
                Range<Integer> isoRange=Camera2CameraInfo.from(camera.getCameraInfo()).getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                Range<Long> shutterRange=Camera2CameraInfo.from(camera.getCameraInfo()).getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                if(capabilities!=null && isoRange!=null && shutterRange!=null){
                    for(int capability:capabilities)if(capability==CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)supported=true;
                    if(supported){
                        int iso=Math.max(isoRange.getLower(),Math.min(isoRange.getUpper(),p.targetIso));
                        long requested=(long)p.exposureMillis*1000000L;
                        long shutter=Math.max(shutterRange.getLower(),Math.min(shutterRange.getUpper(),requested));
                        CaptureRequestOptions opts=new CaptureRequestOptions.Builder()
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_OFF)
                            .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY,iso)
                            .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME,shutter)
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE,CaptureRequest.CONTROL_AWB_MODE_AUTO)
                            .build();
                        control.setCaptureRequestOptions(opts);
                        currentSensorMode="ISO "+iso+" · "+p.exposureMillis+"ms";
                    }
                }
            }
            if(!supported){
                // Auto-exposure is safer for moving people, changing light, and video.
                androidx.camera.core.ExposureState exposure=camera.getCameraInfo().getExposureState();
                if(exposure.isExposureCompensationSupported()){
                    float step=exposure.getExposureCompensationStep().floatValue();
                    if(step>0){
                        int target=Math.round(p.exposureEv/step);
                        Range<Integer> limits=exposure.getExposureCompensationRange();
                        camera.getCameraControl().setExposureCompensationIndex(Math.max(limits.getLower(),Math.min(limits.getUpper(),target)));
                    }
                }
                currentSensorMode="SMART AE · AUTO WB";
            }
            if(status!=null&&!busy)setStatus("● "+p.name+" · "+currentSensorMode);
        }catch(Exception error){
            currentSensorMode="SAFE AUTO";
            if(status!=null&&!busy)setStatus("● "+p.name+" · SAFE AUTO");
        }
    }

    private void setStatus(String s){if(status!=null)status.setText(s);}
    private void capture(){if(busy)return;if(galleryMode){saveGalleryPhoto();return;}if(videoMode){if(recording==null)recordVideo();else stopVideo();}else takePhoto();}
    private String timestamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
    /**
     * Fast shutter: let CameraX finish capture independently from CPU-heavy grading.
     * The camera controls become usable again as soon as the JPEG is captured.
     * Finished photos appear in the gallery a little later. Limit backlog to avoid OOM.
     */
    private void takePhoto(){
        if(imageCapture==null)return;
        if(pendingPhotoSaves.get()>=3){
            setStatus("FINISHING PHOTOS · TRY AGAIN IN A MOMENT");
            return;
        }
        busy=true;
        shutter.setText("◉");
        setStatus("● CAPTURING");
        final File temp=new File(getCacheDir(),"capture_"+System.nanoTime()+".jpg");
        final FilterPreset savedFilter=selected;
        final int savedBeauty=beautyMode;
        ImageCapture.OutputFileOptions output=new ImageCapture.OutputFileOptions.Builder(temp).build();
        imageCapture.takePicture(output,cameraCallbackWorker,new ImageCapture.OnImageSavedCallback(){
            @Override public void onImageSaved(@NonNull ImageCapture.OutputFileResults result){
                pendingPhotoSaves.incrementAndGet();
                runOnUiThread(()->{
                    busy=false;
                    shutter.setText("◎");
                    setStatus("● CAPTURED · SAVING IN BACKGROUND ("+pendingPhotoSaves.get()+")");
                });
                photoWorker.execute(()->{
                    Uri uri=null;
                    Bitmap input=null,prepared=null,beautified=null,processed=null;
                    try{
                        // Decode no more than needed for fast high-quality JPEG export.
                        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
                        BitmapFactory.decodeFile(temp.getAbsolutePath(),bounds);
                        BitmapFactory.Options opts=new BitmapFactory.Options();
                        opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
                        opts.inSampleSize=1;
                        while(Math.max(bounds.outWidth,bounds.outHeight)/opts.inSampleSize>2800)opts.inSampleSize*=2;
                        input=BitmapFactory.decodeFile(temp.getAbsolutePath(),opts);
                        if(input==null)throw new IOException("Unable to decode captured photo");
                        int orientation=new ExifInterface(temp.getAbsolutePath()).getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
                        prepared=rotateExif(input,orientation);
                        // 2600 px long edge produces a faster mobile-camera experience.
                        // Preserve input ratio and avoid additional softening from repeated resampling.
                        int longest=Math.max(prepared.getWidth(),prepared.getHeight());
                        if(longest>2600){
                            float scale=2600f/longest;
                            Bitmap scaled=Bitmap.createScaledBitmap(prepared,
                                Math.max(1,Math.round(prepared.getWidth()*scale)),
                                Math.max(1,Math.round(prepared.getHeight()*scale)),true);
                            if(prepared!=input)prepared.recycle();
                            prepared=scaled;
                        }
                        beautified=savedBeauty==0?prepared:beautyProcessor.process(prepared,savedBeauty);
                        processed=PhotoGrader.apply(beautified,savedFilter);
                        uri=createMedia("image/jpeg","EasyABC_"+timestamp()+"_"+System.nanoTime()%10000+".jpg",
                            Environment.DIRECTORY_PICTURES+"/EasyABC Lens Pro");
                        try(OutputStream stream=getContentResolver().openOutputStream(uri)){
                            if(stream==null||!processed.compress(Bitmap.CompressFormat.JPEG,91,stream))
                                throw new IOException("Cannot save photo");
                        }
                        publish(uri);
                        Uri finished=uri;
                        runOnUiThread(()->{
                            lastUri=finished;lastMime="image/jpeg";
                            setStatus("● SAVED · "+savedFilter.name);
                        });
                    }catch(Exception error){
                        if(uri!=null)getContentResolver().delete(uri,null,null);
                        runOnUiThread(()->{setStatus("PHOTO SAVE FAILED");Toast.makeText(MainActivity.this,"Save failed: "+error.getMessage(),Toast.LENGTH_LONG).show();});
                    }finally{
                        temp.delete();pendingPhotoSaves.decrementAndGet();
                        if(processed!=null)processed.recycle();
                        if(beautified!=null&&beautified!=prepared)beautified.recycle();
                        if(prepared!=null&&prepared!=input)prepared.recycle();
                        if(input!=null)input.recycle();
                    }
                });
            }
            @Override public void onError(@NonNull ImageCaptureException error){
                temp.delete();
                runOnUiThread(()->{busy=false;shutter.setText("◎");setStatus("PHOTO FAILED");Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_LONG).show();});
            }
        });
    }

    /** Open an existing image via Android's document/content picker: no storage permission required. */
    private void openGalleryPhoto(Uri uri){
        if(uri==null||busy)return;
        busy=true;setStatus("OPENING PHOTO FROM GALLERY…");
        galleryGeneration.incrementAndGet();
        worker.execute(()->{
            try {
                BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
                try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("Cannot read selected photo");BitmapFactory.decodeStream(in,null,bounds);}
                if(bounds.outWidth<1||bounds.outHeight<1)throw new IOException("Unsupported photo format");
                BitmapFactory.Options opts=new BitmapFactory.Options();opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
                int maxSide=Math.max(bounds.outWidth,bounds.outHeight);opts.inSampleSize=1;
                while(maxSide/opts.inSampleSize>4400)opts.inSampleSize*=2;
                Bitmap decoded;
                try(InputStream in=getContentResolver().openInputStream(uri)){
                    if(in==null)throw new IOException("Photo is not accessible");decoded=BitmapFactory.decodeStream(in,null,opts);
                }
                if(decoded==null)throw new IOException("Could not decode selected photo");
                int orientation;
                try(InputStream in=getContentResolver().openInputStream(uri)){
                    orientation=in==null?ExifInterface.ORIENTATION_NORMAL:new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
                }
                Bitmap rightWay=rotateExif(decoded,orientation);
                runOnUiThread(()->{
                    // The previous preview is never used as input for the next filter; edits are non-destructive.
                    // Keep old source alive until any background preview using it has finished.
                    gallerySource=rightWay;galleryMode=true;videoMode=false;busy=false;
                    preview.setVisibility(View.INVISIBLE);galleryImage.setVisibility(View.VISIBLE);
                    galleryButton.setText("▣  CHOOSE ANOTHER PHOTO");modeButton.setText("↩  BACK TO CAMERA");
                    cameraButton.setText("↩ CAMERA");shutter.setText("✓");
                    selectedLabel.setText(selected.name);renderGalleryPreview();
                });
            }catch(Exception ex){runOnUiThread(()->{busy=false;setStatus("GALLERY PHOTO FAILED");Toast.makeText(this,"Unable to open photo: "+ex.getMessage(),Toast.LENGTH_LONG).show();});}
        });
    }
    private void returnToCamera(){
        galleryGeneration.incrementAndGet();galleryMode=false;
        galleryImage.setImageDrawable(null);galleryImage.setVisibility(View.GONE);
        preview.setVisibility(View.VISIBLE);galleryButton.setText("▣  EDIT A PHOTO FROM GALLERY");
        modeButton.setText("PHOTO   ●  /   VIDEO");cameraButton.setText("⇄ FLIP");shutter.setText("◎");
        // A pending renderer sees the changed generation and discards its output.
        if(galleryPreviewBitmap!=null){galleryPreviewBitmap.recycle();galleryPreviewBitmap=null;}
        gallerySource=null; // In-flight background preview may still hold its source reference.
        configureCameraPreset();applyLiveLook();setStatus("● READY · OFFLINE CAMERA");
    }
    private void renderGalleryPreview(){
        if(!galleryMode||gallerySource==null)return;
        final int seq=galleryGeneration.incrementAndGet();
        final Bitmap original=gallerySource;final FilterPreset preset=selected;final int mode=beautyMode;
        setStatus("APPLYING  "+preset.name+" · GALLERY PREVIEW…");
        worker.execute(()->{
            Bitmap result=null;
            try {
                if(seq!=galleryGeneration.get()||!galleryMode)return;
                int w=original.getWidth(),h=original.getHeight();
                float scale=Math.min(1f,1280f/Math.max(w,h));
                int pw=Math.max(1,Math.round(w*scale)),ph=Math.max(1,Math.round(h*scale));
                Bitmap sample=scale>=1f?original:Bitmap.createScaledBitmap(original,pw,ph,true);
                Bitmap enhanced=mode==0?sample:beautyProcessor.process(sample,mode);
                try{result=PhotoGrader.apply(enhanced,preset,true);}
                finally{if(enhanced!=sample)enhanced.recycle();if(sample!=original)sample.recycle();}
                Bitmap finalResult=result;
                runOnUiThread(()->{
                    if(seq!=galleryGeneration.get()||!galleryMode){finalResult.recycle();return;}
                    galleryImage.setImageBitmap(finalResult);
                    Bitmap old=galleryPreviewBitmap;galleryPreviewBitmap=finalResult;
                    if(old!=null&&old!=finalResult)old.recycle();
                    setStatus("GALLERY · "+preset.name+" · TAP ✓ TO SAVE COPY");
                });
            }catch(Exception err){if(result!=null)result.recycle();runOnUiThread(()->{if(seq==galleryGeneration.get())setStatus("PREVIEW FAILED — CHOOSE ANOTHER PHOTO");});}
        });
    }
    private void saveGalleryPhoto(){
        if(gallerySource==null||busy)return;
        busy=true;setStatus("EXPORTING PHOTO · "+selected.name+"…");
        final Bitmap original=gallerySource;final FilterPreset filter=selected;final int mode=beautyMode;
        worker.execute(()->{
            Bitmap exported=null;Uri output=null;
            try {
                Bitmap enhanced=mode==0?original:beautyProcessor.process(original,mode);
                try{exported=PhotoGrader.apply(enhanced,filter,true);}
                finally{if(enhanced!=original)enhanced.recycle();}
                output=createMedia("image/jpeg","EasyABC_Edit_"+timestamp()+".jpg",Environment.DIRECTORY_PICTURES+"/EasyABC Lens Pro");
                try(OutputStream stream=getContentResolver().openOutputStream(output)){
                    if(stream==null||!exported.compress(Bitmap.CompressFormat.JPEG,96,stream))throw new IOException("Could not save edited photo");
                }
                publish(output);
                Uri saved=output;
                runOnUiThread(()->completeCapture(saved,"image/jpeg","GALLERY PHOTO SAVED · "+filter.name));
            }catch(Exception error){
                Uri failed=output;if(failed!=null)getContentResolver().delete(failed,null,null);
                runOnUiThread(()->{busy=false;setStatus("GALLERY EXPORT FAILED");Toast.makeText(this,error.getMessage(),Toast.LENGTH_LONG).show();});
            }finally{if(exported!=null)exported.recycle();}
        });
    }

    private Bitmap rotateExif(Bitmap src,int orientation){
        android.graphics.Matrix m=new android.graphics.Matrix();
        switch(orientation){case ExifInterface.ORIENTATION_ROTATE_90:m.postRotate(90);break;case ExifInterface.ORIENTATION_ROTATE_180:m.postRotate(180);break;case ExifInterface.ORIENTATION_ROTATE_270:m.postRotate(270);break;
            case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:m.postScale(-1,1);break;case ExifInterface.ORIENTATION_FLIP_VERTICAL:m.postScale(1,-1);break;default:return src;}
        Bitmap out=Bitmap.createBitmap(src,0,0,src.getWidth(),src.getHeight(),m,true);if(out!=src)src.recycle();return out;
    }
    private void recordVideo(){
        if(videoCapture==null)return;
        try{
            recordingTemp=new File(getCacheDir(),"raw_"+System.nanoTime()+".mp4");
            FileOutputOptions opts=new FileOutputOptions.Builder(recordingTemp).build();
            PendingRecording pending=videoCapture.getOutput().prepareRecording(this,opts);
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) pending=pending.withAudioEnabled();
            FilterPreset videoFilter=selected;
            recording=pending.start(ContextCompat.getMainExecutor(this),event->{
                if(event instanceof VideoRecordEvent.Start){shutter.setText("■");setStatus("● RECORDING · "+videoFilter.name);}
                else if(event instanceof VideoRecordEvent.Finalize){
                    recording=null;shutter.setText("●");
                    VideoRecordEvent.Finalize f=(VideoRecordEvent.Finalize)event;
                    if(f.hasError()){setStatus("RECORDING FAILED");busy=false;Toast.makeText(this,"Video recording failed: "+f.getError(),Toast.LENGTH_LONG).show();}
                    else processVideo(recordingTemp,videoFilter);
                }
            });
        }catch(Exception e){recording=null;busy=false;setStatus("VIDEO UNAVAILABLE");Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void stopVideo(){if(recording==null)return;busy=true;setStatus("PROCESSING VIDEO · PLEASE KEEP APP OPEN");recording.stop();}
    private void processVideo(File raw,FilterPreset filter){
        setStatus("APPLYING "+filter.name+" TO VIDEO…");
        File converted=new File(getCacheDir(),"filtered_"+System.nanoTime()+".mp4");
        List<Effect> effects=new ArrayList<>();
        effects.add(new HslAdjustment.Builder().adjustSaturation(filter.saturation<=-80f?-100f:filter.saturation*.65f)
            .adjustLightness(filter.lightness*.65f).build());
        if(filter.contrast!=0)effects.add(new Contrast(filter.contrast*.65f));
        // Do not shift RGB channels globally: white lights and faces must not turn blue.
        EditedMediaItem item=new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(raw))).setEffects(new Effects(Collections.emptyList(),effects)).build();
        try{
            activeTransformer=new Transformer.Builder(this).addListener(new Transformer.Listener(){
                @Override public void onCompleted(Composition c,ExportResult result){
                    worker.execute(()->{
                        try{
                            Uri out=createMedia("video/mp4","EasyABC_"+timestamp()+".mp4",Environment.DIRECTORY_MOVIES+"/EasyABC Lens Pro");
                            try(InputStream in=new FileInputStream(converted);OutputStream os=getContentResolver().openOutputStream(out)){
                                if(os==null)throw new IOException("Cannot save recording");byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)os.write(b,0,n);
                            }
                            publish(out);raw.delete();converted.delete();
                            runOnUiThread(()->{activeTransformer=null;completeCapture(out,"video/mp4","VIDEO SAVED · "+filter.name);});
                        }catch(Exception e){runOnUiThread(()->videoFailed(raw,"Could not save filtered recording"));}
                    });
                }
                @Override public void onError(Composition c,ExportResult result,ExportException e){activeTransformer=null;converted.delete();videoFailed(raw,"Video filter processing not supported on this device");}
            }).build();
            activeTransformer.start(item,converted.getAbsolutePath());
        }catch(Exception e){activeTransformer=null;videoFailed(raw,"Video processing failed: "+e.getClass().getSimpleName());}
    }
    private void videoFailed(File raw,String msg){
        busy=false;setStatus("VIDEO FILTER FAILED");
        new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Filtered video not saved")
            .setMessage(msg+". The original video is still available temporarily. Save the unfiltered original instead?")
            .setPositiveButton("Save original",(dialog,w)->worker.execute(()->{
                try{Uri uri=createMedia("video/mp4","EasyABC_Original_"+timestamp()+".mp4",Environment.DIRECTORY_MOVIES+"/EasyABC Lens Pro");
                    try(InputStream in=new FileInputStream(raw);OutputStream os=getContentResolver().openOutputStream(uri)){
                        if(os==null)throw new IOException("Unable to save original");byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)os.write(b,0,n);}
                    publish(uri);raw.delete();runOnUiThread(()->completeCapture(uri,"video/mp4","ORIGINAL VIDEO SAVED (NO FILTER)"));
                }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Saving failed",Toast.LENGTH_LONG).show());}
            })).setNegativeButton("Discard",(dialog,w)->raw.delete()).show();
    }
    private Uri createMedia(String mime,String name,String folder)throws IOException{
        ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.DISPLAY_NAME,name);cv.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH,folder);cv.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri collection=mime.startsWith("video")?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Uri uri=getContentResolver().insert(collection,cv);if(uri==null)throw new IOException("Could not create gallery item");return uri;
    }
    private void publish(Uri uri){ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.IS_PENDING,0);getContentResolver().update(uri,cv,null,null);}
    private void completeCapture(Uri uri,String mime,String msg){busy=false;lastUri=uri;lastMime=mime;setStatus(msg);Toast.makeText(this,msg,Toast.LENGTH_LONG).show();}
    private void shareLast(){if(lastUri==null){Toast.makeText(this,"Capture a photo or video first",Toast.LENGTH_SHORT).show();return;}
        Intent intent=new Intent(Intent.ACTION_SEND);intent.setType(lastMime);intent.putExtra(Intent.EXTRA_STREAM,lastUri);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent,"Share your EasyABC capture"));
    }
    private void checkUpdates(){if(busy){Toast.makeText(this,"Complete capture first",Toast.LENGTH_SHORT).show();return;}
        updatesButton.setEnabled(false);setStatus("CHECKING OFFICIAL FILTER PACKS…");store.checkForUpdates((message,changed)->{
            updatesButton.setEnabled(true);setStatus("● READY · OFFLINE CAMERA");
            if(changed){String previous=selected.id;filters=store.load();for(FilterPreset f:filters)if(f.id.equals(previous)){selected=f;break;}refreshFilters();}
            new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("EasyABC Filter Library").setMessage(message).setPositiveButton("OK",null).show();
        });
    }
    @Override protected void onDestroy(){galleryGeneration.incrementAndGet();if(recording!=null){recording.stop();recording=null;}if(activeTransformer!=null){activeTransformer.cancel();activeTransformer=null;}worker.shutdown();photoWorker.shutdown();cameraCallbackWorker.shutdown();beautyProcessor.close();super.onDestroy();}
}
