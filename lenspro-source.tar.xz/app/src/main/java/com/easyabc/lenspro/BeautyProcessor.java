package com.easyabc.lenspro;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;

import java.util.ArrayList;
import java.util.List;

/**
 * Bundled offline ML Kit detection + subtle geometry/skin enhancement.
 * No cloud processing, personal biometric storage, or user-editable strength sliders.
 *
 * Mode 1: soft skin. Mode 2: soft skin and subtle face slimming.
 * Mode 3: soft skin, face slimming, and pose-guided torso slimming.
 * If landmarks are missing/low-confidence, skip the associated effect.
 */
public final class BeautyProcessor {
    private FaceDetector faces;
    private PoseDetector poses;

    private static final class FaceArea {
        final float left, top, width, height;
        FaceArea(float x,float y,float w,float h){left=x;top=y;width=w;height=h;}
    }
    private static final class TorsoArea {
        final float centerX, shouldersY, hipsY, halfWidth;
        TorsoArea(float x,float sy,float hy,float hw){centerX=x;shouldersY=sy;hipsY=hy;halfWidth=hw;}
    }

    private static float clamp(float a,float low,float high){return Math.min(high,Math.max(low,a));}
    private static float smooth(float t){t=clamp(t,0,1);return t*t*(3-2*t);}

    private synchronized FaceDetector getFaces(){
        if(faces==null){
            faces=FaceDetection.getClient(new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
                .setMinFaceSize(.08f).build());
        }
        return faces;
    }
    private synchronized PoseDetector getPoses(){
        if(poses==null){
            poses=PoseDetection.getClient(new PoseDetectorOptions.Builder()
                .setDetectorMode(PoseDetectorOptions.SINGLE_IMAGE_MODE).build());
        }
        return poses;
    }

    public synchronized Bitmap process(Bitmap src,int mode){
        if(mode<=0)return src;
        int w=src.getWidth(),h=src.getHeight();
        Bitmap small=src;
        Bitmap work=null;
        Bitmap smoothResult=null;
        try{
            float scale=Math.min(1f,960f/Math.max(w,h));
            if(scale<1f){small=Bitmap.createScaledBitmap(src,
                Math.max(1,Math.round(w*scale)),Math.max(1,Math.round(h*scale)),true);}
            float sx=w/(float)small.getWidth(),sy=h/(float)small.getHeight();
            List<Face> identified=Tasks.await(getFaces().process(InputImage.fromBitmap(small,0)));
            List<FaceArea> rects=new ArrayList<>();
            for(Face f:identified){
                Rect b=f.getBoundingBox();
                if(b.width()<40||b.height()<40)continue;
                rects.add(new FaceArea(b.left*sx,b.top*sy,b.width()*sx,b.height()*sy));
            }
            TorsoArea torso=null;
            if(mode>=3){
                try{
                    Pose pose=Tasks.await(getPoses().process(InputImage.fromBitmap(small,0)));
                    PoseLandmark ls=pose.getPoseLandmark(PoseLandmark.LEFT_SHOULDER);
                    PoseLandmark rs=pose.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER);
                    PoseLandmark lh=pose.getPoseLandmark(PoseLandmark.LEFT_HIP);
                    PoseLandmark rh=pose.getPoseLandmark(PoseLandmark.RIGHT_HIP);
                    if(valid(ls)&&valid(rs)&&valid(lh)&&valid(rh)){
                        PointF a=ls.getPosition(),b=rs.getPosition(),c=lh.getPosition(),d=rh.getPosition();
                        float sy0=(a.y+b.y)*.5f*sy,hy0=(c.y+d.y)*.5f*sy;
                        float shoulderSpan=Math.abs(a.x-b.x)*sx;
                        float hipSpan=Math.abs(c.x-d.x)*sx;
                        float xx=(a.x+b.x+c.x+d.x)*.25f*sx;
                        // Only front-facing enough poses with a visible torso are safe to reshape.
                        if(hy0-sy0>h*.10f && shoulderSpan>w*.065f && hipSpan>w*.06f){
                            torso=new TorsoArea(xx,sy0,hy0,Math.max(shoulderSpan,hipSpan)*.67f);
                        }
                    }
                }catch(Exception ignored){}
            }
            if(rects.isEmpty()&&torso==null)return src;
            work=src.copy(Bitmap.Config.ARGB_8888,true);
            for(FaceArea f:rects)softenFace(work,f,mode>=2?.46f:.38f);
            if(mode>=2) {
                Bitmap warped=applyGeometry(work,rects,torso);
                work.recycle();work=warped;
            }
            smoothResult=work;work=null;
            return smoothResult;
        }catch(Exception ignored){
            // Fail safe: never lose/replace a customer's photograph if ML isn't available.
            if(work!=null)work.recycle();
            return src;
        }finally{
            if(small!=src)small.recycle();
        }
    }
    private boolean valid(PoseLandmark x){return x!=null&&x.getInFrameLikelihood()>.62f;}

    private static void softenFace(Bitmap bitmap,FaceArea face,float amount){
        int w=bitmap.getWidth(),h=bitmap.getHeight();
        // Face detector bounding boxes often include hair. Only smooth central skin-like region.
        int l=(int)clamp(face.left,0,w-1),t=(int)clamp(face.top,0,h-1);
        int right=(int)clamp(face.left+face.width,1,w),bottom=(int)clamp(face.top+face.height,1,h);
        int rw=right-l,rh=bottom-t;if(rw<48||rh<48)return;
        Bitmap crop=Bitmap.createBitmap(bitmap,l,t,rw,rh);
        Bitmap reduced=Bitmap.createScaledBitmap(crop,Math.max(12,rw/9),Math.max(12,rh/9),true);
        Bitmap smoothed=Bitmap.createScaledBitmap(reduced,rw,rh,true);
        int[] base=new int[rw*rh],blur=new int[rw*rh];
        crop.getPixels(base,0,rw,0,0,rw,rh);smoothed.getPixels(blur,0,rw,0,0,rw,rh);
        float midX=face.left+face.width*.5f,midY=face.top+face.height*.52f;
        float radiusX=face.width*.43f,radiusY=face.height*.48f;
        for(int y=0;y<rh;y++){
            float yy=(y+t-midY)/radiusY;
            for(int x=0;x<rw;x++){
                int i=y*rw+x,c=base[i];
                float xx=(x+l-midX)/radiusX;
                float radial=(float)Math.sqrt(xx*xx+yy*yy);
                float edge=1f-smooth((radial-.68f)/.25f);
                if(edge<=0)continue;
                // Avoid blurring eyes, brows and lips; favor cheeks and forehead skin.
                float fracY=(y+t-face.top)/face.height;
                float eyeZone=(fracY>.20f&&fracY<.47f)?(1f-smooth((fracY-.20f)/.03f))*0.82f:0f;
                float mouthZone=(fracY>.68f&&fracY<.83f)?0.48f:0f;
                float r=(c>>16)&255,g=(c>>8)&255,b=c&255;
                float mx=Math.max(r,Math.max(g,b)),mn=Math.min(r,Math.min(g,b));
                // Broad skin chromaticity detection; protects hair, clothes, lips and eye makeup.
                boolean skin=r>47 && g>29 && b>20 && r>g*.93f && g>b*.75f &&
                    (mx-mn)>11 && Math.abs(r-g)>7 && r>b*1.07f;
                if(!skin)continue;
                float blend=amount*edge*(1-eyeZone)*(1-mouthZone);
                int bc=blur[i];
                int nr=(int)(r+( ((bc>>16)&255)-r)*blend);
                int ng=(int)(g+( ((bc>>8)&255)-g)*blend);
                int nb=(int)(b+((bc&255)-b)*blend);
                base[i]=(c&0xff000000)|(nr<<16)|(ng<<8)|nb;
            }
        }
        bitmap.setPixels(base,0,rw,l,t,rw,rh);
        crop.recycle();reduced.recycle();smoothed.recycle();
    }

    private static Bitmap applyGeometry(Bitmap input,List<FaceArea> faces,TorsoArea torso){
        int w=input.getWidth(),h=input.getHeight();
        // Fine-enough mesh for typical selfie face size, bounded for performance.
        int cols=Math.max(40,Math.min(112,w/16));
        int rows=Math.max(40,Math.min(112,h/16));
        float[] mesh=new float[(cols+1)*(rows+1)*2];
        int k=0;
        for(int y=0;y<=rows;y++){
            float py=h*y/(float)rows;
            for(int x=0;x<=cols;x++){
                float px=w*x/(float)cols;
                float dx=0;
                for(FaceArea face:faces){
                    float cx=face.left+face.width*.5f;
                    float xx=(px-cx)/(face.width*.5f);
                    float yy=(py-face.top)/face.height;
                    // Slim only cheeks/jaw; untouched eyes and forehead.
                    float fallY=smooth((yy-.32f)/.22f)*(1-smooth((yy-.82f)/.19f));
                    float ax=Math.abs(xx);
                    float edgeStrength=smooth(ax/.56f)*(1-smooth((ax-1.08f)/.35f));
                    dx-=Math.signum(xx)*face.width*.028f*fallY*edgeStrength;
                }
                if(torso!=null){
                    float t=(py-torso.shouldersY)/(torso.hipsY-torso.shouldersY);
                    float wave=smooth((t-.17f)/.29f)*(1-smooth((t-.75f)/.28f));
                    float nx=(px-torso.centerX)/torso.halfWidth;
                    float ax=Math.abs(nx);
                    // Modest localized waist taper, not a whole-frame squeeze.
                    float fallX=smooth(ax/.55f)*(1-smooth((ax-1.22f)/.46f));
                    dx-=Math.signum(nx)*torso.halfWidth*.057f*wave*fallX;
                }
                mesh[k++]=clamp(px+dx,0,w);
                mesh[k++]=py;
            }
        }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(out);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmapMesh(input,cols,rows,mesh,0,null,0,paint);
        return out;
    }

    public synchronized void close(){
        if(faces!=null){faces.close();faces=null;}
        if(poses!=null){poses.close();poses=null;}
    }
}
