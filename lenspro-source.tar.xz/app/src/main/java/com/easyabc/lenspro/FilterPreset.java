package com.easyabc.lenspro;

import android.content.Context;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Developer-controlled, read-only photography recipes from the EasyABC reference workbook. */
public final class FilterPreset {
    public final String id,name,collection,shutterGuide,scene,direction;
    public final int isoMin,isoMax,whiteBalanceK,exposureMillis,targetIso;
    public final float exposureEv,contrast,highlights,shadows,saturation,vibrance,clarity,grain,vignette,shadowGrade,highlightGrade;
    public final float[] hslHue,hslSat;
    public final boolean manualExposure,builtIn;
    // Compatibility for Media3's less comprehensive video pipeline.
    public final float lightness,warmth,greenBoost,blueBoost;

    private FilterPreset(JSONObject o,boolean original)throws JSONException {
        this.id=o.getString("id");this.name=o.getString("name");
        this.collection=o.optString("category",o.optString("collection","OFFICIAL"));
        if(!id.matches("[a-z0-9-]{2,40}")||name.length()<2||name.length()>55||collection.length()>32)
            throw new JSONException("Invalid preset identity");
        this.isoMin=(int)bound(o.optInt("isoMin",100),25,12800);
        this.isoMax=(int)bound(o.optInt("isoMax",1600),isoMin,25600);
        this.whiteBalanceK=(int)bound(o.optInt("whiteBalanceK",5200),2500,8000);
        this.exposureEv=bound((float)o.optDouble("exposureEv",0),-1.5f,1.5f);
        this.contrast=bound((float)o.optDouble("contrast",0),-100,100);
        this.highlights=bound((float)o.optDouble("highlights",0),-100,100);
        this.shadows=bound((float)o.optDouble("shadows",0),-100,100);
        this.saturation=bound((float)o.optDouble("saturation",0),-100,100);
        this.vibrance=bound((float)o.optDouble("vibrance",0),-100,100);
        this.clarity=bound((float)o.optDouble("clarity",0),-100,100);
        this.grain=bound((float)o.optDouble("grain",0),0,100);
        this.vignette=bound((float)o.optDouble("vignette",0),0,100);
        this.shadowGrade=bound((float)o.optDouble("shadowGrade",0),-20,20);
        this.highlightGrade=bound((float)o.optDouble("highlightGrade",0),-20,20);
        this.shutterGuide=o.optString("shutterGuide","Auto shutter");
        this.scene=o.optString("scene","");this.direction=o.optString("direction","");
        this.manualExposure=o.optBoolean("manualExposure",false);
        this.exposureMillis=(int)bound(o.optInt("exposureMillis",0),0,20000);
        this.targetIso=(int)bound(o.optInt("targetIso",isoMin),isoMin,isoMax);
        this.hslHue=parseArray(o.optJSONArray("hslHue"),-30,30);
        this.hslSat=parseArray(o.optJSONArray("hslSat"),-100,80);
        this.lightness=shadows*0.10f+highlights*0.025f;
        this.warmth=highlightGrade/100f;this.greenBoost=0;this.blueBoost=0;
        this.builtIn=original;
    }
    private static float bound(float x,float lo,float hi){return Math.max(lo,Math.min(hi,x));}
    private static float[] parseArray(JSONArray a,float lo,float hi){
        float[] result=new float[8];if(a==null)return result;
        for(int i=0;i<Math.min(a.length(),8);i++)result[i]=bound((float)a.optDouble(i,0),lo,hi);
        return result;
    }
    public static List<FilterPreset> defaults(Context context){
        try(InputStream in=context.getAssets().open("official_presets.json")){
            java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
            byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            JSONObject root=new JSONObject(out.toString("UTF-8"));
            JSONArray arr=root.getJSONArray("presets");
            if(arr.length()!=40)throw new IllegalStateException("Expected exactly 40 official filters");
            List<FilterPreset> presets=new ArrayList<>();
            for(int i=0;i<arr.length();i++)presets.add(new FilterPreset(arr.getJSONObject(i),true));
            return presets;
        }catch(Exception e){throw new IllegalStateException("Official filter catalogue unavailable",e);}
    }
    /** JSON-only official external packs; no executable files, user editing or third-party imports. */
    public static FilterPreset fromJson(JSONObject original)throws JSONException{
        JSONObject o=new JSONObject(original.toString());
        if(!o.has("category"))o.put("category",o.optString("collection","OFFICIAL"));
        if(!o.has("contrast"))o.put("contrast",0);
        // Legacy pack fields were expressed in a different range; retain controlled compatibility.
        if(o.optDouble("contrast",0)<1 && o.optDouble("contrast",0)>-1)
            o.put("contrast",o.optDouble("contrast",0)*100);
        if(!o.has("highlights"))o.put("highlights",-20);
        if(!o.has("vibrance"))o.put("vibrance",0);
        return new FilterPreset(o,false);
    }
    /** A lightweight CameraX preview approximation; full Lightroom-inspired rendering is performed on capture/gallery images. */
    public ColorMatrixColorFilter colorFilter(){
        ColorMatrix m=new ColorMatrix(),sat=new ColorMatrix();
        sat.setSaturation(Math.max(0,1f+(saturation+vibrance*.35f)/120f));m.postConcat(sat);
        float c=1f+contrast/250f, bias=127f*(1-c)+(shadows*.12f)+(highlights*.04f);
        ColorMatrix tone=new ColorMatrix(new float[]{c,0,0,0,bias,0,c,0,0,bias,0,0,c,0,bias,0,0,0,1,0});
        m.postConcat(tone);return new ColorMatrixColorFilter(m);
    }
}
