package com.easyabc.lenspro;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;

/** Fixed developer-owned profiles. Customers have no editing controls. */
public final class FilterPreset {
    public final String id,name,collection;
    public final float saturation,lightness,contrast,warmth,greenBoost,blueBoost,exposureEv;
    public final int targetIso, exposureMillis;
    public final boolean manualExposure, builtIn;
    private FilterPreset(String id,String name,String collection,float sat,float light,float contrast,
                         float warmth,float green,float blue,float ev,int iso,int shutter,boolean manual,boolean builtIn) {
        this.id=id;this.name=name;this.collection=collection;this.saturation=sat;this.lightness=light;
        this.contrast=contrast;this.warmth=warmth;this.greenBoost=green;this.blueBoost=blue;
        this.exposureEv=ev;this.targetIso=iso;this.exposureMillis=shutter;
        this.manualExposure=manual;this.builtIn=builtIn;
    }
    private static FilterPreset p(String id,String name,String category,float sat,float l,float c,float w,float green,float blue,float ev,int iso,int shutter,boolean manual){
        return new FilterPreset(id,name,category,sat,l,c,w,green,blue,ev,iso,shutter,manual,true);
    }
    public static List<FilterPreset> defaults(){
        List<FilterPreset> out=new ArrayList<>();
        // PEOPLE — ten official locked looks.
        out.add(p("natural-skin-pro","NATURAL SKIN PRO","PEOPLE",5f,2f,0.035f,0.000f,0.000f,0.000f,0.10f,0,0,false));
        out.add(p("soft-beauty","SOFT BEAUTY","PEOPLE",-5f,6f,-0.070f,0.025f,0.000f,0.000f,0.26f,0,0,false));
        out.add(p("golden-hour-face","GOLDEN HOUR FACE","PEOPLE",8f,4f,0.060f,0.130f,0.000f,0.000f,0.03f,0,0,false));
        out.add(p("studio-portrait","STUDIO PORTRAIT","PEOPLE",-1f,3f,0.120f,0.000f,0.000f,0.000f,0.00f,0,0,false));
        out.add(p("vintage-film-portrait","VINTAGE FILM PORTRAIT","PEOPLE",-15f,2f,-0.035f,0.120f,0.000f,0.000f,-0.10f,0,0,false));
        out.add(p("cafe-candid","CAFÉ CANDID","PEOPLE",2f,5f,0.040f,0.070f,0.000f,0.000f,0.13f,0,0,false));
        out.add(p("night-glow-portrait","NIGHT GLOW PORTRAIT","PEOPLE",5f,5f,0.130f,0.050f,0.000f,0.000f,-0.05f,0,0,false));
        out.add(p("monochrome-classic","MONOCHROME CLASSIC","PEOPLE",-100f,2f,0.130f,0.000f,0.000f,0.000f,0.02f,0,0,false));
        out.add(p("dreamy-pastel-portrait","DREAMY PASTEL PORTRAIT","PEOPLE",-12f,8f,-0.100f,0.060f,0.000f,0.000f,0.20f,0,0,false));
        out.add(p("backlit-glow","BACKLIT GLOW","PEOPLE",4f,8f,-0.030f,0.050f,0.000f,0.000f,-0.12f,0,0,false));
        // SCENERY — ten official locked looks.
        out.add(p("golden-hour","GOLDEN HOUR","SCENERY",12f,4f,0.070f,0.160f,0.020f,0.000f,0.03f,0,0,false));
        out.add(p("moody-cinematic","MOODY CINEMATIC","SCENERY",-13f,-5f,0.220f,0.010f,0.060f,0.070f,-0.25f,0,0,false));
        out.add(p("emerald-forest","EMERALD FOREST","SCENERY",10f,2f,0.110f,0.000f,0.180f,0.020f,-0.08f,0,0,false));
        out.add(p("alpine-blue","ALPINE BLUE","SCENERY",7f,3f,0.140f,0.000f,0.040f,0.190f,-0.06f,0,0,false));
        out.add(p("dreamy-pastel","DREAMY PASTEL","SCENERY",-14f,8f,-0.110f,0.070f,0.010f,0.020f,0.17f,0,0,false));
        out.add(p("misty-sunrise","MISTY SUNRISE","SCENERY",-12f,9f,-0.140f,0.070f,0.020f,0.000f,-0.05f,0,0,false));
        out.add(p("silky-waterfall","SILKY WATERFALL","SCENERY",3f,3f,0.080f,0.000f,0.120f,0.110f,-0.25f,100,100,true));
        out.add(p("autumn-amber","AUTUMN AMBER","SCENERY",9f,3f,0.120f,0.220f,-0.040f,0.000f,-0.12f,0,0,false));
        out.add(p("desert-minimalist","DESERT MINIMALIST","SCENERY",-10f,5f,0.030f,0.130f,-0.050f,0.000f,-0.14f,0,0,false));
        out.add(p("midnight-stars","MIDNIGHT STARS","SCENERY",-2f,-4f,0.220f,0.000f,0.000f,0.160f,-0.33f,1600,1500,true));
        // CITY VIEW — ten official locked looks.
        out.add(p("tokyo-neon-rain","TOKYO NEON RAIN","CITY VIEW",13f,-1f,0.170f,0.000f,0.000f,0.210f,-0.25f,0,0,false));
        out.add(p("cinematic-rainy-street","CINEMATIC RAINY STREET","CITY VIEW",-8f,-2f,0.170f,0.010f,0.000f,0.080f,-0.12f,0,0,false));
        out.add(p("rainy-cafe-film","RAINY CAFÉ FILM","CITY VIEW",-10f,5f,-0.015f,0.160f,0.000f,0.000f,-0.01f,0,0,false));
        out.add(p("city-blue-hour","CITY BLUE HOUR","CITY VIEW",2f,-2f,0.160f,0.000f,0.000f,0.190f,-0.24f,0,0,false));
        out.add(p("urban-after-rain","URBAN AFTER RAIN","CITY VIEW",1f,2f,0.130f,0.030f,0.000f,0.110f,-0.11f,0,0,false));
        out.add(p("minimalist-architecture","MINIMALIST ARCHITECTURE","CITY VIEW",-17f,5f,0.140f,0.000f,0.000f,0.030f,0.09f,0,0,false));
        out.add(p("vintage-cafe-warmth","VINTAGE CAFÉ WARMTH","CITY VIEW",-12f,5f,-0.030f,0.190f,0.000f,0.000f,-0.08f,0,0,false));
        out.add(p("metro-motion","METRO MOTION","CITY VIEW",-7f,-2f,0.190f,0.000f,0.000f,0.090f,-0.35f,100,30,true));
        out.add(p("rooftop-golden-hour","ROOFTOP GOLDEN HOUR","CITY VIEW",8f,3f,0.110f,0.180f,0.000f,0.000f,-0.11f,0,0,false));
        out.add(p("night-market-glow","NIGHT MARKET GLOW","CITY VIEW",12f,5f,0.120f,0.110f,0.000f,0.020f,-0.11f,0,0,false));
        // FOOD & DRINKS — ten official locked looks.
        out.add(p("coffee-crema","COFFEE CREMA","FOOD & DRINKS",8f,4f,0.080f,0.140f,0.000f,0.000f,-0.05f,0,0,false));
        out.add(p("warm-bakery","WARM BAKERY","FOOD & DRINKS",8f,4f,0.070f,0.170f,0.000f,0.000f,0.05f,0,0,false));
        out.add(p("menu-studio","MENU STUDIO","FOOD & DRINKS",2f,6f,0.110f,0.000f,0.000f,0.000f,0.13f,0,0,false));
        out.add(p("dark-moody-plate","DARK MOODY PLATE","FOOD & DRINKS",-7f,-6f,0.260f,0.060f,0.000f,0.000f,-0.27f,0,0,false));
        out.add(p("fresh-greens","FRESH GREENS","FOOD & DRINKS",7f,3f,0.070f,0.000f,0.200f,0.000f,-0.04f,0,0,false));
        out.add(p("sweet-pastel","SWEET PASTEL","FOOD & DRINKS",-11f,8f,-0.100f,0.070f,0.010f,0.000f,0.20f,0,0,false));
        out.add(p("street-food-night","STREET FOOD NIGHT","FOOD & DRINKS",12f,3f,0.140f,0.100f,0.000f,0.000f,-0.15f,0,0,false));
        out.add(p("golden-crispy","GOLDEN CRISPY","FOOD & DRINKS",11f,4f,0.130f,0.180f,0.000f,0.000f,0.05f,0,0,false));
        out.add(p("iced-drinks-sparkle","ICED DRINKS SPARKLE","FOOD & DRINKS",4f,6f,0.120f,0.000f,0.000f,0.110f,0.14f,0,0,false));
        out.add(p("candlelit-dining","CANDLELIT DINING","FOOD & DRINKS",-8f,2f,0.160f,0.180f,0.000f,0.000f,-0.17f,0,0,false));
        if(out.size()!=40) throw new IllegalStateException("40 official presets expected");
        return out;
    }
    /** External filter packs remain developer-controlled and safely bounded; no user imports. */
    public static FilterPreset fromJson(JSONObject o)throws JSONException {
        String id=o.getString("id"),name=o.getString("name"),category=o.optString("collection","OFFICIAL");
        if(!id.matches("[a-z0-9-]{2,40}")||name.length()<2||name.length()>40||category.length()>24)throw new JSONException("Invalid preset identity");
        float sat=(float)o.optDouble("saturation",0),light=(float)o.optDouble("lightness",0),contrast=(float)o.optDouble("contrast",0);
        // Legacy external-pack RGB values are mapped to colour-selective strengths; never global RGB gains.
        float warm=(float)((o.optDouble("red",1)-o.optDouble("blue",1))*0.22);
        float green=(float)(o.optDouble("green",1)-1)*0.6f;
        float blue=(float)(o.optDouble("blue",1)-1)*0.6f;
        if(!valid(sat,-100,40)||!valid(light,-25,25)||!valid(contrast,-0.25f,0.4f)||
            !valid(warm,-0.25f,0.25f)||!valid(green,-0.25f,0.25f)||!valid(blue,-0.25f,0.25f))throw new JSONException("Unsafe preset values");
        return new FilterPreset(id,name,category,sat,light,contrast,warm,green,blue,0,0,0,false,false);
    }
    private static boolean valid(float v,float lo,float hi){return Float.isFinite(v)&&v>=lo&&v<=hi;}
    /** Preview deliberately applies no global blue-channel gain. Saved photo processing is selective. */
    public ColorMatrix colorMatrix(){
        ColorMatrix matrix=new ColorMatrix();
        ColorMatrix sat=new ColorMatrix();sat.setSaturation(Math.max(0,1+saturation/110f));matrix.postConcat(sat);
        float k=1+contrast*.65f;
        float bias=lightness*.55f+128f*(1-k);
        ColorMatrix tone=new ColorMatrix(new float[]{
            k,0,0,0,bias,0,k,0,0,bias,0,0,k,0,bias,0,0,0,1,0});
        matrix.postConcat(tone);return matrix;
    }
    public ColorMatrixColorFilter colorFilter(){return new ColorMatrixColorFilter(colorMatrix());}
}
