package com.easyabc.lenspro;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;

/** Trusted, immutable developer-defined filter configuration. Never exposed as user sliders. */
public final class FilterPreset {
    public final String id, name, collection;
    public final float hue, saturation, lightness, contrast, red, green, blue;
    public final boolean builtIn;
    public FilterPreset(String id, String name, String collection, float hue, float saturation,
                        float lightness, float contrast, float red, float green, float blue, boolean builtIn) {
        this.id=id; this.name=name; this.collection=collection; this.hue=hue;
        this.saturation=saturation; this.lightness=lightness; this.contrast=contrast;
        this.red=red; this.green=green; this.blue=blue; this.builtIn=builtIn;
    }
    private static FilterPreset p(String id,String name,String collection,float hue,float sat,float light,float contrast,float r,float g,float b){
        return new FilterPreset(id,name,collection,hue,sat,light,contrast,r,g,b,true);
    }
    public static List<FilterPreset> defaults() {
        List<FilterPreset> a=new ArrayList<>();
        a.add(p("natural","NATURAL","ESSENTIAL",0,0,0,0,1,1,1));
        a.add(p("nature-pro","NATURE PRO","SCENERY",-2,19,2,0.09f,1.00f,1.06f,0.98f));
        a.add(p("cinematic","CINEMATIC","FILM",-5,-12,-3,0.18f,1.10f,1.02f,1.13f));
        a.add(p("golden-hour","GOLDEN HOUR CLASSIC","SCENERY",4,15,5,0.07f,1.12f,1.05f,0.88f));
        a.add(p("moody","MOODY PRO","FILM",-4,-24,-7,0.22f,0.90f,1.03f,1.12f));
        a.add(p("ocean","OCEAN BLUE","SCENERY",-7,21,2,0.11f,0.96f,1.08f,1.16f));
        a.add(p("forest","FOREST ULTRA","SCENERY",-6,10,-2,0.15f,0.91f,1.12f,0.93f));
        a.add(p("city-night","CITY NIGHT","NIGHT",-6,10,-5,0.24f,0.97f,1.01f,1.16f));
        a.add(p("sunset","SUNSET GLOW","SCENERY",5,23,2,0.12f,1.13f,0.98f,0.90f));
        a.add(p("vintage","VINTAGE FILM","FILM",6,-26,4,-0.04f,1.09f,1.00f,0.82f));
        a.add(p("bw","MONO CLASSIC","MONO",0,-100,1,0.17f,1,1,1));
        a.add(p("bw-drama","MONO DRAMA","MONO",0,-100,-5,0.32f,1,1,1));
        a.add(p("clean","CLEAN PRO","ESSENTIAL",0,6,5,0.08f,1.02f,1.03f,1.01f));
        a.add(p("travel","TRAVEL POP","SCENERY",-1,26,3,0.12f,1.04f,1.05f,1.02f));
        a.add(p("mist","SOFT MIST","FILM",-3,-17,8,-0.10f,0.98f,1.02f,1.07f));
        a.add(p("desert","DESERT SAND","SCENERY",7,8,3,0.12f,1.10f,1.02f,0.87f));
        a.add(p("urban","URBAN STEEL","FILM",-8,-17,-3,0.18f,0.94f,1.01f,1.13f));
        a.add(p("flower","FLORAL","SCENERY",5,17,5,0.06f,1.10f,1.01f,1.07f));
        a.add(p("morning","MORNING LIGHT","SCENERY",2,8,7,-0.03f,1.06f,1.04f,0.99f));
        a.add(p("night","NIGHT GLOW","NIGHT",-4,2,3,0.10f,1.04f,1.02f,1.11f));

        // EasyABC Scenery Pro: five official, fixed colour grades.
        // Existing Golden Hour remains as GOLDEN HOUR CLASSIC for continuity.
        a.add(p("scenery-golden-hour","GOLDEN HOUR","SCENERY PRO",6,17,5,0.12f,1.19f,1.09f,0.82f));
        a.add(p("scenery-moody-cinematic","MOODY CINEMATIC","SCENERY PRO",-8,-19,-7,0.28f,0.89f,1.10f,1.00f));
        a.add(p("scenery-emerald-forest","EMERALD FOREST","SCENERY PRO",-7,8,2,0.05f,0.91f,1.19f,0.96f));
        a.add(p("scenery-alpine-blue","ALPINE BLUE","SCENERY PRO",-9,17,3,0.18f,0.94f,1.07f,1.23f));
        a.add(p("scenery-dreamy-pastel","DREAMY PASTEL","SCENERY PRO",5,-23,9,-0.13f,1.13f,0.99f,1.12f));

        // EasyABC City View: fixed rain, urban, and blue-hour looks.
        // Camera ISO, shutter, and white balance remain device-controlled:
        // these presets define the saved colour grade, not guaranteed sensor settings.
        a.add(p("city-tokyo-neon-rain","TOKYO NEON RAIN","CITY VIEW",-11,23,-2,0.27f,1.13f,0.96f,1.27f));
        a.add(p("city-cinematic-rainy-street","CINEMATIC RAINY STREET","CITY VIEW",-8,-24,-8,0.23f,0.92f,1.03f,1.15f));
        a.add(p("city-rainy-cafe-film","RAINY CAFÉ FILM","CITY VIEW",5,-18,3,0.08f,1.19f,1.03f,0.91f));
        a.add(p("city-blue-hour","CITY BLUE HOUR","CITY VIEW",-12,9,-5,0.24f,0.93f,1.04f,1.28f));
        a.add(p("city-urban-after-rain","URBAN AFTER RAIN","CITY VIEW",-5,5,0,0.17f,1.13f,1.03f,1.10f));
        return a;
    }
    public static FilterPreset fromJson(JSONObject o) throws JSONException {
        String id=o.getString("id"), name=o.getString("name"), collection=o.optString("collection","NEW");
        if(!id.matches("[a-z0-9-]{2,40}") || name.length()>32 || name.length()<2 || collection.length()>20) throw new JSONException("Invalid filter identity");
        float hue=(float)o.optDouble("hue",0), sat=(float)o.optDouble("saturation",0), light=(float)o.optDouble("lightness",0),contrast=(float)o.optDouble("contrast",0);
        float r=(float)o.optDouble("red",1),g=(float)o.optDouble("green",1),b=(float)o.optDouble("blue",1);
        if(!inside(hue,-25,25)||!inside(sat,-100,80)||!inside(light,-40,40)||!inside(contrast,-0.5f,0.7f)||!inside(r,0.5f,1.5f)||!inside(g,0.5f,1.5f)||!inside(b,0.5f,1.5f)) throw new JSONException("Out of bounds filter settings");
        return new FilterPreset(id,name,collection,hue,sat,light,contrast,r,g,b,false);
    }
    private static boolean inside(float v,float a,float b){return !Float.isNaN(v)&&!Float.isInfinite(v)&&v>=a&&v<=b;}
    /** Shared approximate colour transform for photo pixels and live camera preview. */
    public ColorMatrix colorMatrix() {
        ColorMatrix cm=new ColorMatrix();
        ColorMatrix sat=new ColorMatrix(); sat.setSaturation(Math.max(0,1+saturation/100f)); cm.postConcat(sat);
        // Approximate RGB hue rotation around neutral axis.
        if(Math.abs(hue)>0.01f) { ColorMatrix rotation=new ColorMatrix(); rotation.setRotate(0,hue); cm.postConcat(rotation); }
        float k=1+contrast; float lift=lightness*1.55f + 128f*(1-k);
        ColorMatrix rgb=new ColorMatrix(new float[]{
            k*red,0,0,0,lift, 0,k*green,0,0,lift, 0,0,k*blue,0,lift, 0,0,0,1,0 });
        cm.postConcat(rgb);return cm;
    }
    public ColorMatrixColorFilter colorFilter(){return new ColorMatrixColorFilter(colorMatrix());}
}
