# EasyABC Lens Pro v1.2.0 — 40 Professional Locked Presets

Android 10+ offline camera app. Replaces the original 30 built-in looks with **exactly forty** official scene-specific presets across four groups: SELFIE/PEOPLE, SCENERY, CITY/CAFÉ, FOOD & DRINKS (ten each). Users cannot create, adjust or import arbitrary presets. The existing official, opt-in online filter catalogue remains available.

## Improvements
- Photo processing uses an on-device per-pixel selective grade: blue emphasis is applied to blue-dominant scene pixels, green emphasis to vegetation, warming to warm regions. Skin-like tones receive greatly reduced grading. Whites and nearly-neutral highlights are pulled back to neutral, preventing a blue cast on white shirts and lights.
- The camera adjusts device-supported auto exposure compensation to preset targets. Three tripod/long-exposure creative photo looks (Silky Waterfall, Midnight Stars, Metro Motion) request hardware ISO + shutter values only on Camera2 MANUAL_SENSOR devices; otherwise they fall back to auto exposure. White balance remains automatic to avoid blue or orange white surfaces. The camera exposes no manual setting sliders.
- Video output remains neutral-safe, with mild Media3 HSL saturation, lightness and contrast processing; it does not use global RGB colour gain. The photo processor and video processor cannot yet guarantee exactly matching output on every device.
- Android 12+ applies an approximate live preview look; lower Android versions show a clean preview, and the processed photo is saved. Hardware and lighting conditions determine the actual sensor result.

## Limitations
Reference aesthetics are directions, not guarantees of a particular photo match. A phone cannot create real rain, night stars, silky water, bokeh or long exposure motion via colour adjustment alone. Exposure time controls are hardware-dependent; long shutter looks require a tripod and bright scenes can overexpose. All 40 are calibrated starting values: detailed matching requires reference images and device testing. Test on a real Android phone before offering as a customer-facing release.

## Build
`gradle :app:assembleDebug` using Gradle 8.11.1, JDK 17 and Android SDK 35. Production distribution requires a persistent signing key, device QA and security checks.
