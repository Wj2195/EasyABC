# EasyABC Lens Pro v1.3.0 — Lightroom-inspired 40 locked recipes + Gallery Editor

Android-only offline camera application. The 40 preset definitions are derived from `EasyABC_Lens_Pro_40_Preset_Camera_Settings.xlsx`, which contains professional-inspired creative starting points, not actual EXIF metadata of reference photographs.

## Changes

- Replaced brightness-centric grading with a tone + colour-development engine: exposure, contrast, independent highlights/shadows, matte/film tone curves, 8-hue-band HSL mixer, vibrance, local clarity, grain, and vignette.
- All 40 recipe parameters and descriptions are packaged in `app/src/main/assets/official_presets.json` and **not editable by customers**.
- Neutral whites are protected from global RGB colour casts. Skin-like colours get protection in all categories. This is chromaticity-based heuristic protection, **not human-face AI segmentation**.
- New `EDIT A PHOTO FROM GALLERY` opens Android's secure image picker, shows a true final-filter preview, and exports a **new** JPEG copy into Pictures/EasyABC Lens Pro; the original picture remains unchanged. Gallery edits also work offline, and saved photos use the same 40 photo-processing recipes as camera capture.
- Photo capture ISO guidance, camera exposure compensation (AE EV) and long-exposure presets are applied where Camera2 hardware supports them. ISO, shutter and aperture cannot be retroactively changed for existing gallery images. On non-manual devices, the app uses safe auto-exposure and auto white balance.
- Live CameraX preview uses an *approximation* of the still-photo filters. The saved picture and gallery photo previews use the full processor. Video continues to use an approximate Media3 colour pipeline; it is **not** an identical implementation of the still-photo filter.

## Build

GitHub Actions (branch `lens-pro-apk-build`) is the Android SDK/Gradle builder. On a machine with Android Studio/SDK and JDK 17:

```bash
gradle :app:assembleDebug
```

The result is `app/build/outputs/apk/debug/app-debug.apk`. This debug APK is for testing, not signing/releasing for commercial distribution.

## Camera controls versus post-processing

Camera ISO, shutter speed, hardware white balance, stabilisation and optics depend on the device. The WB Kelvin in the recipes influences safe selective split-toning while camera AWB protects neutrals. These adjustments approximate a photographic style; they **cannot guarantee any fixed visual similarity percentage** with reference photos. Real rain, sunset, bokeh and stars require real scenes/optical or computational photography and cannot be generated from filters alone.

## Operational safeguards

- Customers cannot save or change any preset slider.
- Gallery photo access is via Android Content Picker, no bulk gallery permission.
- Camera/photo/video processing remains offline; update checking is optional.
- Imported photos are never overwritten.
- Official external filter packs remain HTTPS-host restricted and checked with SHA-256; unsigned checksum-based catalogues are not authentication against a compromised publisher, so add signature verification before public releases.
