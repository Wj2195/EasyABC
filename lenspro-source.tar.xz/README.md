# EasyABC Lens Pro v1.1.0 — Android

An Android 10+ native camera app with **locked official preset filters**. Customers can choose presets but cannot create, import, change, or adjust filter parameters.

## App features
- 30 built-in offline professional scene and film presets, including the five fixed SCENERY PRO and five fixed CITY VIEW looks
- CameraX photo capture saved as a filter-applied JPEG to Pictures/EasyABC Lens Pro
- 720p-class HD video recording with Media3 on-device preset processing, saved to Movies/EasyABC Lens Pro. Processing begins after recording stops and can take time; keep app open. If the processing fails, user is offered the option to explicitly save the original *unfiltered* video.
- Real-time filter approximation for camera preview on Android 12+ (older Android versions show unfiltered preview but filter photos and videos after capture)
- Switch rear/front cameras (where available)
- Native Android share sheet for WhatsApp, Instagram, TikTok etc, provided those apps are installed
- Optional official filter pack download from EasyABC website, SHA-256 verified, with strict HTTPS host/path, app-private storage, and bounds checks
- No customer filter editing, account, telemetry, or remote access

## Compile with Android SDK
Requires JDK 17, Android SDK 35 and Gradle 8.11.1.

```bash
gradle :app:assembleDebug
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

For production/public distribution, create a signed release keystore under your sole control and run an Android release build. Do **not** publicly distribute a debug-signed APK as your permanent production signature.

## Official filter catalogue
The app checks `https://wj2195.github.io/EasyABC/lenspro/catalog.json` only when a customer taps `FILTERS ↻`. Place `sample-filter-library/catalog.json` and the `packs` directory at `EasyABC/lenspro/` to enable additional official filters. The bundled sample includes one pack; its sha256 is computed in the sample catalogue. Update it when changing files. Any missing catalogue means offline presets still work.

Additional packs are JSON only; there is no code download, customer import, or mutable UI. Package updates are applied atomically to app-private storage. Secure transport and SHA256 protect integrity, while repository publishing access controls remain critical to catalogue authenticity. A future production release could add offline public-key signature verification.

## Limitations / validation
- This is a first functional build. Actual hardware camera/encoding behaviour must be tested on physical Android devices. An app can build without having been device-tested.
- Media3 preset processing occurs **after recording**. Live preview uses a close approximation and may differ from final export.
- Actual video resolution depends on device support and CameraX fallback.
- A new APK release is required for new filter-engine capabilities beyond bundled color-grading controls.
- Playback/sharing uses the OS and installed applications; publishing posts automatically is not included.

## V1.1 preset additions

**SCENERY PRO (five locked official presets)**: Golden Hour, Moody Cinematic, Emerald Forest, Alpine Blue, Dreamy Pastel.

**CITY VIEW (five locked official presets)**: Tokyo Neon Rain, Cinematic Rainy Street, Rainy Café Film, City Blue Hour, Urban After Rain.

On the camera screen, select ALL, SCENERY · 5, or CITY VIEW · 5. In category mode only those five presets appear in the horizontal selection strip. User colour adjustments, user-defined presets and third-party filter imports are never offered.

The 10 new filters are permanent offline colour-grade presets applied to saved photographs and processed videos. The preset styles approximate the named moods using hue, saturation, lightness, contrast, and RGB channel grading. Rain, atmospheric fog, simulated bokeh, grain and long-exposure effects are not generated. Suggested ISO, shutter-speed and white-balance ranges from the photography reference are guidelines, not forced or guaranteed camera sensor controls in V1.1. Live camera preview remains approximate and platform-dependent.

This debug-signed build may use a different signing certificate from the previous test APK. If an in-place upgrade fails, uninstall the previous test APK first (downloaded packs may be deleted), then install V1.1. Photos and videos saved to the gallery are separate from app-private filter data. Use a persistent private release signing key for customer updates.
