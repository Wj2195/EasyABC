# EasyABC Lens Pro v1.4 — Fast Camera and Offline Selfie Beauty

Android-only offline Android CameraX camera. V1.4 test APK is optimized for **64-bit ARM (arm64-v8a)** Android devices; legacy 32-bit Android and x86 emulators need a separate APK build. Contains 40 locked EasyABC photography presets and gallery editing.

## Faster camera experience
- `ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY` reduces camera pipeline waiting time; camera characteristics and lighting will still affect actual shutter lag.
- Capture callbacks run on their own executor, separate from the photo-processing queue.
- Camera UI is freed once a capture has been handed off for processing, even while its JPEG is still being filtered/saved.
- New captures can happen while up to three photos are saving, protecting memory on lower-end phones.
- Background filtered JPEG export uses a maximum 2,600-pixel long edge and JPEG quality 91 to reduce processing latency and memory compared with the old full-resolution processing. This trades some output resolution for speed; upgrade to an optional high-quality/full-resolution output if needed.
- A photo should be shared only after the app shows `SAVED`; until then it is queued in the background. Saving still takes time.

## Selfie Beauty (locked modes, offline)
Tap the `SELFIE BEAUTY` button to select one of four fixed effects:
- OFF: no reshaping
- SOFT SKIN: moderate skin smoothing within detected facial regions, keeping white clothes and backgrounds unaffected
- FACE SLIM: soft skin + localized 2.8%-of-face-width cheek/jaw warp
- FACE + BODY SLIM: soft skin + localized face contour warp and mild pose-guided waist taper.

Bundled ML Kit Face Detection and Pose Detection run fully on the device. Face/torso reshaping is applied to saved **photos and gallery exports**, NOT to the live camera preview, videos, or situations where detection landmarks are missing/low-confidence. The skin smoothing prioritizes skin-like colours and avoids most of the eye/mouth region. Body slimming is designed for a single clearly-visible front-facing person and may skip if shoulders/hips are not detected. No biometric info is stored or uploaded.

## Build
Android JDK 17/Gradle 8.11.1 and SDK 35 with Google Maven. `gradle :app:assembleDebug`.
The debug APK is for testing. Hardware camera, portrait and gallery testing is needed before production release.
